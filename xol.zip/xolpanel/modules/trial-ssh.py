from xolpanel import *

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 1 Menit ","1")],
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		user = "trial-"+str(random.randint(100,1000))
		pw = "1"
		cmd = f'printf "%s\n" "{user}" "{exp}" | trialbot'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**⟨ SSH OVPN ACCOUNT ⟩**
**━━━━━━━━━━━━━━━━━**
**» Username :** `{user.strip()}`
**» Password :** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━**
**» Host             :** `{DOMAIN}`
**» Host Slowdns     :** `{HOST}`
**» Pub Key          :** `{PUB}`
**» Port OpenSSH     :** `443, 80, 22`
**» Port DNS         :** `443, 53 ,22`
**» Port Dropbear    :** `143, 109`
**» Port SSH WS      :** `80`
**» Port SSH SSL WS  :** `443`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `443, 1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** `3128`
**» BadVPN UDP       :** `7100 - 7300`
**━━━━━━━━━━━━━━━━━**
**» Payload WSS      :** `GET wss://bug.com/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» OpenVPN Download:** `https://{DOMAIN}:81`
**━━━━━━━━━━━━━━━━━**
**» Save Link Account:** `https://{DOMAIN}:81/ssh-{user.strip()}.txt`
**━━━━━━━━━━━━━━━━━**
**» Expired:** `{exp} Minutes`
**━━━━━━━━━━━━━━━━━**

"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)